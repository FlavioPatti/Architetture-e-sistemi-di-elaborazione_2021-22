/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
#include "../led/led.h"
#include "../timer/timer.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

#define N 4

extern int sopra_la_media(unsigned char VETT[], unsigned int n);

int value=0;
int prec_value=0;
unsigned char vettore[N]; 
int risultato;
int int0=0;
int key1=0;
int key2=0;
int i=0;	
int up=0;
int left=0;
int select=0;


void RIT_IRQHandler (void)
{					
	
	// disable_timer(1);
	// catturare valore del timer: val_int = LPC_TIM1->TC;	
	// enable_timer(1);
	
	if((LPC_GPIO1->FIOPIN & (1<<26)) == 0){	
		/* Joytick Select pressed */
		select++;
		switch(select){
			case 1:
				disable_timer(0);
				i=0;
				value = 0;
				LED_Out(value);
				break;
			default:
				break;
		}
	}
	else{
			select=0;
	}
	
	if((LPC_GPIO1->FIOPIN & (1<<27)) == 0){	
		/* Joytick left pressed */
		left++;
		switch(left){
			case 1: //10
				if(value>=1){
				value = value -1;
				LED_Out(value);
				}
				break;
			default:
				break;
		}
	}
	else{
			left=0;
	}


	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){	
		/* Joytick up pressed */
		up++;
		switch(up){
			case 1: //10
				if(value<=254){
				value = value +1;
				LED_Out(value);
				}
				break;
			default:
				break;
		}
	}
	else{
			up=0;
	}
	
	/* button management */
	if(int0 > 1){ 
		if((LPC_GPIO2->FIOPIN & (1<<10)) == 0){	/* INT0 pressed */				
			switch(int0){
				case 2:
					if(i==N || prec_value == value){
						risultato = sopra_la_media(vettore,N);
						if(risultato>=0 && risultato <=255){
							LED_Out(risultato);
							enable_timer(0);
						}
					}
					if(i<N){
					vettore[i++]=value;
					prec_value = value;
					value = 0;
					}
					break;
				default:
					break;
			}
			int0++;
		}
		else {	/* button released */
			int0=0;			
			NVIC_EnableIRQ(EINT0_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 20);     /* External interrupt 0 pin selection */
		}
	}
	else {
		if (int0 == 1)
			int0++;
	}
	
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
