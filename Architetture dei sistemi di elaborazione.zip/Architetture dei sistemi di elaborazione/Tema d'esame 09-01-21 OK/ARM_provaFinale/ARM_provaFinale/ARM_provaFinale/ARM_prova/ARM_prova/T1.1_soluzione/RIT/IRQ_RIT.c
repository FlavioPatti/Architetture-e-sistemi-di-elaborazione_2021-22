/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
#include "../led/led.h"
#include "../timer/timer.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

#define N 4

extern int count_negative_and_odd(int* VETT, unsigned int n); 

int vett[N]; 
int i=0;
int select=0;
int down=0;
int up=0;
int var1=0;
int ris;

void RIT_IRQHandler (void)
{					
	
	//il joystick � gi� antirimbalzo per hardware
	// catturare valore del timer: val_int = LPC_TIM1->TC;	
	
	if((LPC_GPIO1->FIOPIN & (1<<28)) == 0){	
		/* Joytick Select pressed */
		select++;
		switch(select){
			case 1:
			vett[i++]= var1;
			var1=0;
			if(i==N){
				ris = count_negative_and_odd(vett,N);
				i=0;
			}
			if(ris==0){
				enable_timer(0);
				LED_On(0);
			}else{
				ris = ris << 1;
				LED_Out(ris);
			}
				break;
			default:
				break;
		}
	}
	else{
			select=0;
	}

	if((LPC_GPIO1->FIOPIN & (1<<26)) == 0){	
		/* Joytick down pressed */
		down++;
		switch(down){
			case 1:
		var1-=8;
				break;
			default:
				break;
		}
	}
	else{
			down=0;
	}

	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){	
		/* Joytick up pressed */
		up++;
		switch(up){
			case 1:
				var1+=12;
				break;
			default:
				break;
		}
	}
	else{
			up=0;
	}

	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
