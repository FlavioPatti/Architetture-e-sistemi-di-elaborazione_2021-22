/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
#include "../led/led.h"
#include "../timer/timer.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

#define N 4

extern int diff_bits(int*, int *,int );

int V[N]={0};
int V2[N/2]={0};
int diff_values;
int key1=0;
int up=0;
int acquisition=1; //1=acquisizione, 0 = display
int pointer=0;


void RIT_IRQHandler (void)
{					
	

	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0 && acquisition == 1){	
		/* Joytick up pressed */
		up++;
		switch(up){
			case 1:
				enable_timer(1);
			  enable_timer(2);
				V[pointer++]=LPC_TIM1->TC;
				V[pointer++]=LPC_TIM2->TC;
			if( pointer == N ) pointer = 0;
				break;
			default:
				break;
		}
	}
	else{
			up=0;
	}

	
	/* button management */
	if(key1 > 1){ 
		if((LPC_GPIO2->FIOPIN & (1<<11)) == 0){	/* KEY1 pressed */				
			switch(key1){
				case 2:
				acquisition = 0;
				diff_values = diff_bits(V,V2,N);
				enable_timer(0);
						
					break;
				default:
					break;
			}
			key1++;
		}
		else {	/* button released */
			key1=0;			
			NVIC_EnableIRQ(EINT1_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 22);     /* External interrupt 0 pin selection */
		}
	}
	else { //gestione rimbalzo dei bottoni
		if(key1 == 1)
			key1++;
	}
	
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
