The solution is logically correct but hasn't really been tested on the board, so feel free to use it as a guide, not as a surely working solution.

I took the assembly "overflow.s" file from professor Bernardi solution.
Andrea Spitale
