/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
#include "../led/led.h"
#include "../timer/timer.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

#define N 4

extern int overflow(int v[N], int n);

int value=0;
int vett[N]; 
int ris;
int i=0;	
int up=0;

void RIT_IRQHandler (void)
{					
	

	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){	
		/* Joytick up pressed */
		up++;
		switch(up){
			case 1:
				value = LPC_TIM1->TC;	
				vett[i++]= value;
				if(i==N){
				ris = overflow(vett,4);
				LED_On(ris);
				}
			case 60:
				enable_timer(0);
			
				break;
			default:
				break;
		}
	}
	else{
			up=0;
			disable_timer(0);
	}
	
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
