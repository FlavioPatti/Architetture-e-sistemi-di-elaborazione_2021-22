/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
#include "../led/led.h"
#include "../timer/timer.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

#define N 8

extern char get_and_sort(unsigned char* VETT, unsigned char VAL, int n);

int val_int;
unsigned char val_char;
unsigned char vett[N];
int n=0;
int key1=0;
int i=0;

void RIT_IRQHandler (void)
{					
	
	/* button management */
	if(key1 > 1){ 
		if((LPC_GPIO2->FIOPIN & (1<<11)) == 0){	/* KEY1 pressed */				
			switch(key1){
				case 2:
					disable_timer(1);
					val_int = LPC_TIM1->TC;			
					enable_timer(1);	
			  	//devo estrarre il 3' byte
					val_char = (val_int & 0x00ff0000) >> 16;
					n++;
					get_and_sort(vett, val_char, n);
					if(n<N) LED_Out(n);
					else{
						LED_Out(vett[0]);
						enable_timer(0);
						i++;
					}
					break;
				default:
					break;
			}
			key1++;
		}
		else {	/* button released */
			key1=0;	
			if(n<N){ //non voglio piu entrare nel rit ma voglio che gestisca tutto il timer0
			NVIC_EnableIRQ(EINT1_IRQn);								/* enable Button interrupts			*/
			}
			LPC_PINCON->PINSEL4    |= (1 << 22);     /* External interrupt 0 pin selection */
		}
	}
	else { //gestione rimbalzo dei bottoni
		if(key1 == 1)
			key1++;
	}
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
