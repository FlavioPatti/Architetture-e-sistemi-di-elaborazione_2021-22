/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "timer.h"
#include "../led/led.h"

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
*********************************************************
*********************/
#define N 4
extern int i;
extern unsigned int vett[N];
extern int val1;
extern int ris;
extern int average(unsigned int* VETT, unsigned int n); 
int j;

//implemento il lampeggiare dei led
void TIMER0_IRQHandler (void)
{	
	
	if(i<N){
	vett[i++]=val1;
	val1=0;
	}
	if(i==N){
		i=0;
		disable_timer(1);
		ris = average(vett,4);
		if(ris==0) LED_Out(128);
		if(ris>=1 && ris<=63) LED_Out(ris);
		if(ris>63){
			enable_timer(1);
		}
	}
	
	
  LPC_TIM0->IR = 1;			/* clear interrupt flag */
  return;
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER1_IRQHandler (void)
{
	j++;
	if(j%2==0)
		LED_On(7);
	else
		LED_Off(7);
	
  LPC_TIM1->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
