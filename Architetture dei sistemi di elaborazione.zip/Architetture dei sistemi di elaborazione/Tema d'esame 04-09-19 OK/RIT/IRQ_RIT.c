/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
#include "../led/led.h"
#include "../timer/timer.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

#define N 4

extern int strictly_monotone_ascending(int* VETT, unsigned int n);

int vett[N]={0};
int key1=0;
int res;
int count = 0;

void RIT_IRQHandler (void)
{					
	
	/* button management */
	if(key1 > 1){ 
		if((LPC_GPIO2->FIOPIN & (1<<11)) == 0){	/* KEY1 pressed */
			switch(key1){
				case 2:
				disable_timer(0); //stoppa il timer
				vett[count++] = LPC_TIM0->TC; //prendo il valore corrente del timer0					
				enable_timer(0); //lo faccio ripartire
				if(count==N){
					res = strictly_monotone_ascending(vett,N);
					count=0;
					LED_Out(res & 0x000000FF); //azzera tutti i bit di res che non sono di interesse e mi tiene solo il byte meno significativo che 
					//andra ad essere stampato negli 8 led
				}
					break;
				default:
					break;
			}
			key1++;
		}
		else {	/* button released */
			key1=0;
			NVIC_EnableIRQ(EINT1_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 22);     /* External interrupt 0 pin selection */
		}
	}
	else {
		if(key1 == 1)
			key1++;
	}
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
